<?php

namespace App\Middleware;

class Role{
    const ADMIN = "setAdmin";
    const MANAJER = "setManajer";
}