<?php
namespace App\Exception;
class ResponseException extends \Exception{

}