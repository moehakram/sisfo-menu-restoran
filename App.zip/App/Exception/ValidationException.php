<?php
namespace App\Exception;
class ValidationException extends \Exception{

}