<?php
namespace App\Domain;

class Session
{
    public string $id;
    public string $userId;
}