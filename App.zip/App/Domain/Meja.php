<?php

namespace App\Domain;

class Meja{
    public int $nomor;
    public int $status;
}