<?php

namespace App\Domain;

class Status
{
    public int $id;
    public string $statusUser;
    public string $statusPesan;
    public string $statusOrder;
    public string $statusMenu;
    public string $statusMeja;
}
