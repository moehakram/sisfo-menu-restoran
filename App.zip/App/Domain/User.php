<?php

namespace App\Domain;

class User{
    public string $id;
    public string $name;
    public string $password;
    public int $level;
    public int $status;
}