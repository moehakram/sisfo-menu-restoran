<?php
namespace app\Models;
use App\Domain\User;

class UserRegisterResponse{

    public User $user;
}