<?php
namespace app\Models;

class UserLoginRequest{
    public ?string $id = null;
    public ?string $password = null;
}