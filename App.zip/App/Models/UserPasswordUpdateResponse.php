<?php
namespace app\Models;
use App\Domain\User;

class UserPasswordUpdateResponse
{
    public User $user;
}