<?php
namespace app\Models;
class UserProfileUpdateRequest
{
    public ?string $id = null;
    public ?string $name = null;
}