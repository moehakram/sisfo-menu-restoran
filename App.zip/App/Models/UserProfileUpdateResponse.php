<?php
namespace app\Models;
use App\Domain\User;

class UserProfileUpdateResponse
{
    public User $user;
}