<?php
namespace app\Models;
use App\Domain\User;

class UserLoginResponse{
    public User $user;
}