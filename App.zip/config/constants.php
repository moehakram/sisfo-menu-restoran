<?php

// Define Path app
define('ROOT', str_replace('\\', '/', rtrim(__DIR__, '/')) . '/../');
define('APP', ROOT . 'App/');
define('CONTROLLERS', ROOT . 'App/Controllers/');
define('MODELS', ROOT . 'App/Models/');
define('VIEWS', ROOT . 'App/views/');
define('UPLOAD', ROOT . 'upload/');
define('CONFIG', ROOT . 'config/');
define('ROUTER', ROOT . 'router/');

define('BASE_URL', "https://akram.bajuragam.my.id/");

define('SRC_UPLOAD', 'https://akram.bajuragam.my.id/upload/');
define('SRC_PUBLIC', 'https://akram.bajuragam.my.id/');

